package OrderDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import ApplicationModels.Item;
import ConnectionUtil.DbConnection;
import ItemDAO.ItemDAO;

public class OrderDAO {
	private Connection connection; 
	
	public OrderDAO() {
		
		try {
			connection = new DbConnection().getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			
		}
	}

	public String CreateOrder(List<Item> Items) {
		// TODO Auto-generated method stub
		try
		{
			String expenseUUID = UUID.randomUUID().toString();
			expenseUUID = expenseUUID.replaceAll("-", "");
			
			java.util.Date dt = new java.util.Date();

			java.text.SimpleDateFormat sdf = 
			     new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			String currentTime = sdf.format(dt);
			
			Statement statement = connection.createStatement();
			
			for (Item item : Items) {
				
			int quantity = Integer.parseInt(item.getQuantity());
			String Query = "insert into orders (OrderId,ItemId,OrderDate,Quantity) values(\""+expenseUUID+"\","+item.getId()+",\""+currentTime+"\","+quantity+")";
			statement.executeUpdate(Query);
			}
			return expenseUUID;

		} catch (SQLException error) {

			error.printStackTrace();
		}
		return null;
	}

	//-----imp ---- Here the quantity is imp and i dont know how to return 
	public List<Item> GetOrderItems(String orderId) throws Exception{

		try{
			List<Item> itemsList = new ArrayList<Item>();
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from userordermap where OrderId='"+orderId+"'");
			
			while (rs.next()) {
						ItemDAO itemDao = new ItemDAO();
			            Item item = itemDao.GetItem(rs.getInt("ItemId"));
			            itemsList.add(item);
			}
		return itemsList;
		}  catch (SQLException error) {

			error.printStackTrace();
		}
		return null;
	}

	



}
