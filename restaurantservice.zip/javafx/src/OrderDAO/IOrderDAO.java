package OrderDAO;

import java.sql.Date;
import java.util.List;

import ApplicationModels.Item;

public interface IOrderDAO {

	Boolean CreateOrder(List<Item> items);
	
	List<Item> GetOrderItems(String orderId);
}
