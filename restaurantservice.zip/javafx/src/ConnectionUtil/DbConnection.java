package ConnectionUtil;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbConnection {
	private static Connection connection = null;  
	private static String Driver ="com.mysql.jdbc.Driver";
	private static String Url ="jdbc:mysql://localhost:3306/restaurant";
	private static String UserName ="root";
	private static String Password ="root";
	  
	  
    public static Connection getConnection() throws Exception {  
  
        if (connection != null)  
  
            return connection;  
  
        else {  
  
            try {  
  
 
                Class.forName(Driver);  
  
                connection = DriverManager.getConnection(Url, UserName, Password);  
  
            } catch (ClassNotFoundException e) {  
  
                e.printStackTrace(); 
                throw new ClassNotFoundException("ClassNotFound"+e.getMessage());
  
            } catch (SQLException e) {  
  
                e.printStackTrace();  
                throw new SQLException("SQLException"+e.getMessage());
  
            }   
            return connection;  
  
        }  
  
  
  
    }  
}
