package UserOrderMapDAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ApplicationModels.UserOrderMap;
import ConnectionUtil.DbConnection;

public class UserOrderMapDAO {
	private Connection connection; 
	
	public UserOrderMapDAO(){
		
		try {
			connection = new DbConnection().getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			
		}
	}
	public Boolean Insert(String OrderId,int TableNumber,int OrderStatus,int UserId){
		try
		{

			Statement statement = connection.createStatement();
			String Query = "insert into UserOrderMap(OrderId,OrderStatus,TableNumber,UserId) values(\""+OrderId+"\","+OrderStatus+","+TableNumber+","+UserId+")";
			statement.executeUpdate(Query);
			return true;
			
		}catch(Exception ex){
			ex.printStackTrace();
			return false;
		}
	}
	public int getOrderIdforUser(int userId) throws Exception{

		try{
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select orderid from userordermap where UserId='"+userId+"' and OrderStatus=1");
			return rs.getInt("OrderId");

		} catch (Exception e){
			e.printStackTrace();
			return 0;
		
		}	
	}

	public List<Integer> getListOfOrderIds(String orderStatus) throws Exception{

		try{
			List<Integer> listOfOrderId = new ArrayList<Integer>();
			
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select orderid from userordermap where OrderStatus='"+orderStatus+"'");
			while (rs.next()) 
				listOfOrderId.add(rs.getInt("orderId"));
			
			return listOfOrderId;

		} catch (Exception e){
			e.printStackTrace();
			return null;
		    
		}
	}

	public List<UserOrderMap> GetOpenBills(){
		try
		{
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from userordermap where OrderStatus='"+0+"'");
			List<UserOrderMap> bills = new ArrayList<UserOrderMap>();
			while(rs.next()){
				
				UserOrderMap bill = new UserOrderMap();
				bill.setId(Integer.parseInt(rs.getString("Id")));

				bill.setTableNumber(Integer.parseInt(rs.getString("TableNumber")));
				bills.add(bill);
			}
			return bills;
		}catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	// to do !!!
	public Boolean UpdateOrderStatus(int orderId) throws Exception{

		try{
			Statement statement = connection.createStatement();
			statement.executeUpdate("update userordermap set OrderStatus=1 where Id='"+orderId+"'");
			return true;
		} catch (Exception e){
			e.printStackTrace();
			return true;
		
		}	
	}

}
