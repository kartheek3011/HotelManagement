package UserOrderMapDAO;

import java.util.List;

import ApplicationModels.UserOrderMap;

public interface IUserOrderMapDAO {
	
	Boolean Insert(String OrderId,int TableNumber,int OrderStatus,int UserId);
	int getOrderIdforUser(int userId);
	List<Integer> getListOfOrderIds(String orderStatus);
	List<UserOrderMap> GetOpenBills();
	Boolean UpdateOrderStatus(int orderId);
}
