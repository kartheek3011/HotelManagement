package ApplicationController;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import ApplicationModels.Item;
import ApplicationModels.User;
import ItemDAO.ItemDAO;
import OrderDAO.OrderDAO;
import TablesDAO.TablesDAO;
import UserDAO.UserDAO;
import UserOrderMapDAO.UserOrderMapDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class MenuController implements Initializable {
	

	@FXML private Label CustomerName;
	@FXML private TableView<Item> itemtable;
	@FXML private TableColumn<Item, Integer> Id;
	@FXML private TableColumn<Item, String> ItemName;
	@FXML private TableColumn<Item,Integer> Price;
	@FXML private ChoiceBox<Integer> Tables;
	@FXML private TableColumn<Item,String> Quantity;
	private ItemDAO items = new ItemDAO();
	private TablesDAO tables = new TablesDAO();
	private OrderDAO Orders = new OrderDAO();
	private UserDAO user = new UserDAO();
	private UserOrderMapDAO maporder = new UserOrderMapDAO();
	
	private String Username ;
	private final ObservableList<Item> list =
    FXCollections.observableArrayList(

    		items.GetItemList()
    		
    );
	

	public void SetUserName(String  UserName){
		Username = UserName;
		CustomerName.setText("Hi "+UserName+"\t Enjoy Your Food !!!");	
	}
	
	public void SetVacantTables(){
		
		Tables.getItems().addAll(tables.getVacantTables());
	}
	
	public void initialize(URL location, ResourceBundle resources) {



		
		itemtable.setEditable(true);
		Id.setCellValueFactory(new PropertyValueFactory<Item, Integer>("Id"));
		ItemName.setCellValueFactory(new PropertyValueFactory<Item, String>("ItemName"));
		Price.setCellValueFactory(new PropertyValueFactory<Item, Integer>("Price"));
		Quantity.setCellValueFactory(
		            new PropertyValueFactory<Item, String>("Quantity"));
		Quantity.setCellFactory(TextFieldTableCell.forTableColumn());
		Quantity.setOnEditCommit(
			    new EventHandler<CellEditEvent<Item, String>>() {
			        @Override
			        public void handle(CellEditEvent<Item, String> t) {
			            ((Item) t.getTableView().getItems().get(
			                t.getTablePosition().getRow())
			                ).setQuantity(t.getNewValue());
			        }
			    }
			);
		itemtable.setItems(list);


	}
	public void placeorder(ActionEvent event){
		
		try
		{
		if(Tables.getValue()==null){
		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Information Dialog");
		alert.setHeaderText("No Tables Vacant");
		alert.showAndWait();
		return ;
		}
		User User = user.GetUser(Username);
		int UserId = User.getId();
		
		List<Item> OrderedList = new ArrayList<Item>();
		for (Item item : list) {
			
			if(Integer.parseInt(item.getQuantity())>0){
				
				OrderedList.add(item);
		
			}
			
		}
		
		if(OrderedList.size()>0)
		{
		
			
			String OrderId = Orders.CreateOrder(OrderedList);
			int TableNumber = Tables.getValue();
			int OrderStatus = 0;
			maporder.Insert(OrderId,TableNumber,OrderStatus,UserId);
			tables.StatusUpdateToOccupied(TableNumber);
			Alert successAlert = new Alert(AlertType.INFORMATION);
			successAlert.setTitle("Information Dialog");
			successAlert.setHeaderText("Order Placed");
			successAlert.showAndWait();
		}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public void signout(ActionEvent event){
		((Node)event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();


		Pane root = null;
		try {
			root = loader.load(getClass().getResource("/ApplicationViews/prelogin.fxml").openStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		   Scene scene = new Scene(root);
		   scene.getStylesheets().add(getClass().getResource("/ApplicationViews/application.css").toExternalForm());
		   primaryStage.setScene(scene);
		   primaryStage.show();

	}

}
