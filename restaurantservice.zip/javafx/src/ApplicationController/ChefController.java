package ApplicationController;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.management.Notification;
import javax.management.NotificationEmitter;

import ApplicationModels.Item;
import ItemDAO.ItemDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ChefController implements Initializable{

	

	@FXML
	private Button AddItem;
	@FXML
	private Button Remove;
	@FXML
	private TextField NewItemName;
	@FXML
	private TextField NewItemStatus;
	@FXML
	private TextField NewPrice;
	
	
	@FXML private TableView<Item> Menu;
	@FXML private TableColumn<Item, String> ItemStatus;
	@FXML private TableColumn<Item, String> ItemName;
	@FXML private TableColumn<Item,Integer> Price;
	@FXML private Label displayName ;
	
	private ItemDAO items = new ItemDAO();
	
	private final ObservableList<Item> list =
		    FXCollections.observableArrayList(

		    		items.GetItemList()
		    		
		    );
public void SetUserName(String UserName){
	displayName.setText(UserName);
}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		Menu.setEditable(true);
		Price.setCellValueFactory(new PropertyValueFactory<Item, Integer>("Price"));
		ItemName.setCellValueFactory(new PropertyValueFactory<Item, String>("ItemName"));
		
		ItemStatus.setCellValueFactory(
	            new PropertyValueFactory<Item, String>("ItemStatus"));
		ItemStatus.setCellFactory(TextFieldTableCell.forTableColumn());
		ItemStatus.setOnEditCommit(
		    new EventHandler<CellEditEvent<Item, String>>() {
		        @Override
		        public void handle(CellEditEvent<Item, String> t) {
		            ((Item) t.getTableView().getItems().get(
		                t.getTablePosition().getRow())
		                ).setItemStatus(t.getNewValue());
		        }
		    }
		);
		AddItem.setOnAction(new EventHandler<ActionEvent>() {
		    @Override public void handle(ActionEvent e) {
		    	list.add(new Item(
		    			NewItemName.getText(),
		    			NewItemStatus.getText(),
		    			Integer.parseInt(NewPrice.getText())
		    	
		        )); 
		    	
		    	NewItemName.clear();
		    	NewItemStatus.clear();
		    	NewPrice.clear();
		    }
		});
	
		Remove.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				if(Menu.getSelectionModel().isEmpty()){
					
				}else
				{
					Item item = Menu.getSelectionModel().getSelectedItem();
					items.DeleteItem(item.getItemName());
					list.remove(Menu.getSelectionModel().getSelectedItem());
				}
				
			}
			
		});
		Menu.setItems(list);

		
		
	}

	
	public void SaveMenu(ActionEvent event){
		try
		{
			for (Item item : list) {
				
				if(item.getItemStatus().equals("New")){
					items.CreateItem(item.getItemName(), item.getPrice());
				}
				
			}
			
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("Menu Saved");
			alert.showAndWait();
			
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public void signout(ActionEvent event){
		((Node)event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();


		Pane root = null;
		try {
			root = loader.load(getClass().getResource("/ApplicationViews/prelogin.fxml").openStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		   Scene scene = new Scene(root);
		   scene.getStylesheets().add(getClass().getResource("/ApplicationViews/application.css").toExternalForm());
		   primaryStage.setScene(scene);
		   primaryStage.show();

	}

}
