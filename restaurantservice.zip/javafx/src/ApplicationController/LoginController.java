package ApplicationController;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import UserDAO.UserDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LoginController implements Initializable {

 public UserDAO user = new UserDAO();


   @FXML
   private Label Role;
   @FXML
	private TextField pass;
   @FXML
	private TextField id;

 @Override


 public void initialize(URL location, ResourceBundle resources) {
  // TODO Auto-generated method stub
   }
 
 public void setRole(String role){
	 Role.setText(role);
 }
 public void login(ActionEvent event) throws SQLException{

if(user.AuthenticateUser(id.getText(),pass.getText(),Role.getText())){
	
	((Node)event.getSource()).getScene().getWindow().hide();
	Stage primaryStage = new Stage();
	FXMLLoader loader = new FXMLLoader();


	Pane root = null;
	try {
		if(Role.getText().equals("Customer"))
		{
			root = loader.load(getClass().getResource("/ApplicationViews/customer.fxml").openStream());
			CustomerController custcontroller =  (CustomerController)loader.getController();
			custcontroller.getuserid(id.getText());
			
		}else if(Role.getText().equals("Manager"))
			{
			root = loader.load(getClass().getResource("/ApplicationViews/Manager.fxml").openStream());
			}
		else if(Role.getText().equals("Chef"))
			{
			root = loader.load(getClass().getResource("/ApplicationViews/Chef.fxml").openStream());
			ChefController chefcontroller =  (ChefController)loader.getController();
			chefcontroller.SetUserName(id.getText());
			
			}

	
	
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   Scene scene = new Scene(root);
	   scene.getStylesheets().add(getClass().getResource("/ApplicationViews/application.css").toExternalForm());
	   primaryStage.setScene(scene);
	   primaryStage.show();

}
else{
	
	Alert alert = new Alert(AlertType.ERROR);
	alert.setTitle("Information Dialog");
	alert.setHeaderText("Invalid User Retry");
	alert.showAndWait();
	

}
	}

	public void goback(ActionEvent event){
		((Node)event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();


		Pane root = null;
		try {
			root = loader.load(getClass().getResource("/ApplicationViews/prelogin.fxml").openStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		   Scene scene = new Scene(root);
		   scene.getStylesheets().add(getClass().getResource("/ApplicationViews/application.css").toExternalForm());
		   primaryStage.setScene(scene);
		   primaryStage.show();

	}

 
}