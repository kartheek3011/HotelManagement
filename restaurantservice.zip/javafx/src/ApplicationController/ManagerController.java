package ApplicationController;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import ApplicationModels.Item;
import ApplicationModels.UserOrderMap;
import UserOrderMapDAO.UserOrderMapDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ManagerController implements Initializable {

	@FXML private TableView<UserOrderMap> Bills;
	@FXML private TableColumn<Item, Integer> OrderId;
	@FXML private TableColumn<Item, Integer> TableNumber;
	@FXML private TableColumn<Item, String> PaidStatus;
	@FXML private TextField BillNumber;
	
	UserOrderMapDAO bill = new UserOrderMapDAO();
	
	private final ObservableList<UserOrderMap> bills =
		    FXCollections.observableArrayList(

		    		bill.GetOpenBills()
		    		
		    );
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		Bills.setEditable(true);
		OrderId.setCellValueFactory(new PropertyValueFactory<Item, Integer>("Id"));
		TableNumber.setCellValueFactory(new PropertyValueFactory<Item, Integer>("TableNumber"));
		PaidStatus.setCellValueFactory(new PropertyValueFactory<Item, String>("PaidStatus"));
		
		Bills.setItems(bills);

		
	}

	public void PayBill(ActionEvent event){
		try
		{
			int UserOrderMapId = Integer.parseInt(BillNumber.getText());
			
			bill.UpdateOrderStatus(UserOrderMapId);
			

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("Order "+UserOrderMapId+"\t Bill Payed");
			alert.showAndWait();
			
			((Node)event.getSource()).getScene().getWindow().hide();
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader();
			Pane root = null;
			root = loader.load(getClass().getResource("/ApplicationViews/Manager.fxml").openStream());

			   Scene scene = new Scene(root);
			   scene.getStylesheets().add(getClass().getResource("/ApplicationViews/application.css").toExternalForm());
			   primaryStage.setScene(scene);
			   primaryStage.show();

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public void signout(ActionEvent event){
		((Node)event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();


		Pane root = null;
		try {
			root = loader.load(getClass().getResource("/ApplicationViews/prelogin.fxml").openStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		   Scene scene = new Scene(root);
		   scene.getStylesheets().add(getClass().getResource("/ApplicationViews/application.css").toExternalForm());
		   primaryStage.setScene(scene);
		   primaryStage.show();

	}

}
