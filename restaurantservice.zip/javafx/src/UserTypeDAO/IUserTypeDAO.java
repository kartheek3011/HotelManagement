package UserTypeDAO;

import java.util.List;

import ApplicationModels.UserType;

public interface IUserTypeDAO {


	List<UserType> GetAllTypes();

}
