package UserTypeDAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ApplicationModels.UserType;
import ConnectionUtil.DbConnection;

public class UserTypeDAO {

	
private Connection connection; 
	
	
	public UserTypeDAO() {
		try {
			connection = new DbConnection().getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			
		}
	}
	
	
	public List<UserType> GetAllTypes() {
		// TODO Auto-generated method stub
		
		try
		{
			List<UserType> types = new ArrayList<UserType>();
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from usertype");
			
			while (rs.next()) {
				
					UserType type = new UserType();
					type.setId(rs.getInt("Id"));
					type.setType(rs.getString("Type"));
					
					types.add(type);
			}
			
			return types;
			
		}catch(Exception Error){
			Error.printStackTrace();
			return null;
		}
		
		
	}


}
