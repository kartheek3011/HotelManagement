package ApplicationModels;

public class Tables {
	private int Id;
	private int Status;

	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
	public int getStatus() {
		return Status;
	}
	public void setStatus(int status) {
		Status= status;
	}

}
