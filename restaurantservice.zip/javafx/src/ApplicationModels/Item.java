package ApplicationModels;

import javafx.beans.property.SimpleStringProperty;

public class Item {

	
	private int Id;
	private String  ItemName ;
	private int Price;
	private int Status;
	private String  Quantity = "0";
	private String ItemStatus = "Active";
	
	public Item(){
		
	}
	 public Item(String ItemName, String Status,int Price) {
         this.ItemName = ItemName;
         this.Price = Price;
         this.ItemStatus = Status;
         this.Status = 1;
     }
	public String getItemStatus() {
		return ItemStatus;
	}
	public void setItemStatus(String itemStatus) {
		ItemStatus = itemStatus;
	}
	public String getQuantity() {
		return Quantity;
	}
	public void setQuantity(String quantity) {
		Quantity = quantity;
	}
	
	

	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getItemName() {
		return ItemName;
	}
	public void setItemName(String itemName) {
		ItemName = itemName;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	public int getStatus() {
		return Status;
	}
	public void setStatus(int status) {
		Status= status;
	}

	

	 
	 
}
