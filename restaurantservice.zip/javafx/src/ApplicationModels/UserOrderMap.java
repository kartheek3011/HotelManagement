package ApplicationModels;

public class UserOrderMap {
	private int Id;
	
	private int  UserId ;
	private String  OrderId ;
	private int  OrderStatus ;
	private int TableNumber ;
	private String PaidStatus = "NotPaid";
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getPaidStatus() {
		return PaidStatus;
	}
	public void setPaidStatus(String paidStatus) {
		PaidStatus = paidStatus;
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getOrderId() {
		return OrderId;
	}
	public void setOrderId(String orderId) {
		OrderId = orderId;
	}
	public int getOrderStatus() {
		return OrderStatus;
	}
	public void setOrderStatus(int orderStatus) {
		OrderStatus = orderStatus;
	}
	public int getTableNumber() {
		return TableNumber;
	}
	public void setTableNumber(int tableNumber) {
		TableNumber = tableNumber;
	}


}
