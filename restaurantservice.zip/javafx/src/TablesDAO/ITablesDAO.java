package TablesDAO;

import java.util.List;

public interface ITablesDAO {

	Boolean StatusUpdateToOccupied(int tableId);
	Boolean StatusUpdateToUnOccupied(int tableId);
	List<Integer> getVacantTables();
}
