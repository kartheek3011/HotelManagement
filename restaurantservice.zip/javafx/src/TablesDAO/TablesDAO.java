package TablesDAO;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ConnectionUtil.DbConnection;

public class TablesDAO {
	private Connection connection; 
	
	public TablesDAO(){
		
		try {
			connection = new DbConnection().getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}
	public Boolean StatusUpdateToOccupied(int tableId) throws Exception{
	
	try {
		Statement statement = connection.createStatement();
		statement.executeUpdate("update tables set Status=1 where id='"+tableId+"'");
		
		return true;
	} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
			
	}
	}
	public Boolean StatusUpdateToUnOccupied(int tableId){

		try
		{
		Statement statement = connection.createStatement();
		statement.executeUpdate("update tables set status=0 where id='"+tableId+"'");
		return true;
	
	} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		
	}
}

	public List<Integer> getVacantTables(){
		try
		{
		Statement statement = connection.createStatement();
		ResultSet  rs = statement.executeQuery("select * from tables where Status =0");
		
		List<Integer> vacantTables = new ArrayList<Integer>();
		while(rs.next()){
			vacantTables.add(rs.getInt("Id"));
		}
		return vacantTables;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		
	}
	
}
