package UserDAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ApplicationModels.User;
import ApplicationModels.UserType;
import ConnectionUtil.DbConnection;
import UserTypeDAO.UserTypeDAO;

public class UserDAO {
	private Connection connection; 
	
	public UserDAO(){
		
		try {
			connection = DbConnection.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			
		}
		
	}
	
	public Boolean AuthenticateUser(String UserName, String Password,String UserType) {
		// TODO Auto-generated method stub
		try
		{
			Statement statement = connection.createStatement();
			UserTypeDAO type = new UserTypeDAO();
			List<UserType> types = new ArrayList<UserType>();
			 types = type.GetAllTypes();
			 int TypeId =0 ;
			 for (UserType userType2 : types) {
				
				 if(userType2.getType().equals(UserType)){
					 TypeId = userType2.getId();
					 break;
				 }
			}
			ResultSet rs = statement.executeQuery("select * from user where UserName='"+UserName+"' and UserTypeId ='"+TypeId+"' and Password='"+Password+"'");
			
			if (!rs.first()) {
			    // throw error or return
				return false;
			}
			else
				return true;
			
		}catch(SQLException error){
			error.printStackTrace();
		}
		return null;
	}
	
	public User GetUser(String UserName) {
		// TODO Auto-generated method stub
		try{
			
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from user where UserName='"+UserName+"'");
			
			User user = new User();  
	       	  
			 while (rs.next()) {  
				  
	  
	                user.setId(rs.getInt("Id"));  
	  
	                user.setUserName(rs.getString("UserName"));  
	  
	                user.setPassword(rs.getString("Password"));  
	  
	                user.setEmail(rs.getString("Email"));  
	  
	                user.setUserTypeId(rs.getInt("UserTypeId"));  
	  
	  
	            }  
     
			 return user;
			 
		}catch(Exception error){
			error.printStackTrace();
			return null;
		}
	}

}
