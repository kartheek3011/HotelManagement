package UserDAO;

import ApplicationModels.User;

public interface IUserDAO {

 Boolean AuthenticateUser(String UserName , String Password);
	
	User GetUser(String UserName);

}
