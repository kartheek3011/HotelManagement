package ItemDAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ApplicationModels.Item;
import ConnectionUtil.DbConnection;

public class ItemDAO {
	private Connection connection; 
	
	public ItemDAO(){
		
		try {
			connection = new DbConnection().getConnection();
		} catch (Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Boolean CreateItem(String itemName, int price) {
		// TODO Auto-generated method stub
		try
		{
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from Item where ItemName='"+itemName+"' and Status='"+0+"'");
			
			if (rs.first()) {
			    // throw error or return
				statement.executeUpdate("update Item set status=1 where ItemName='"+itemName+"'");
				return true;
			}
			else{
				statement.executeUpdate("insert into item (ItemName,Price,Status) values('"+itemName+"','"+price+"','"+1+"')");
				return true;
			}
			
		} catch (SQLException error) {

			error.printStackTrace();
		}
		return null;
	}

	
	public Item GetItem(int itemId){

		try
		{
		Statement statement = connection.createStatement();
		ResultSet  rs = statement.executeQuery("select * from Item where ItemId='"+itemId+"' and Status='"+1+"'");

		Item item = new Item();
        item.setId(rs.getInt("Id"));
        item.setItemName(rs.getString("ItemName"));
        item.setPrice(rs.getInt("Price"));
        item.setStatus(rs.getInt("Status"));

        return item;
        
		}catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	} 	
		
	//TODO with the return of objects .

	public List<Item> GetItemList() {

		try{

			List<Item> itemsList = new ArrayList<Item>();
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from Item where Status=1");

			while (rs.next()) {
			            Item item = new Item();
			            item.setId(rs.getInt("Id"));
			            item.setItemName(rs.getString("Itemname"));
			            item.setPrice(rs.getInt("Price"));
			            item.setStatus(rs.getInt("Status"));
			            itemsList.add(item);
			        }
			return itemsList;

		}catch (SQLException error) {

			error.printStackTrace();
			return null;
		}
	}
	
	public Boolean DeleteItem(String itemName) {
		// TODO Auto-generated method stub
		try
		{
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from Item where ItemName='"+itemName+"' and Status='"+1+"'");
			
			if (!rs.first()) {
			    // throw error or return
				return false;
			}
			else{
				statement.executeUpdate("update item set status=0 where ItemName='"+itemName+"'");
				return true;
			}
			
		} catch (SQLException error) {

			error.printStackTrace();
		}
		return null;
	}				

	}

