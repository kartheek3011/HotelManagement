package ItemDAO;

import java.util.List;

import ApplicationModels.Item;

public interface IItemDAO {

	Boolean CreateItem(String itemName, Double price);
	Item GetItem(int itemId);
	List<Item> GetItemList();
	Boolean DeleteItem(String itemName);
}
